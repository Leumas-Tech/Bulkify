export const fileTypes = [
    ".txt",
    ".json", 
  ];
  