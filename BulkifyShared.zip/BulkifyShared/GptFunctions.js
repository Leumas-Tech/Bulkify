import axios from 'axios';

const MAX_PROMPT_BATCH_SIZE = 10;

export async function gpt(prompt = ['tell me that I forgot the prompt'], model = 'gpt-3.5-turbo') {
  // Flatten the prompt if necessary
  if (!Array.isArray(prompt)) {
    prompt = [prompt];
  }
  const flatPrompt = flatten(prompt);

  // Convert the prompt into a series of messages
  const messages = flatPrompt.map(text => ({ role: 'user', content: text }));

  let response = [];
  try {
    // Make the API request with the structured messages
    const responseBatch = await axios.post(`${import.meta.env.VITE_REACT_APP_LEUMAS_AI_ENDPOINT}/openai/chatgpt/chat-completions/chat-completion`, {
      model,
      messages
    });
    response = responseBatch;
  } catch (error) {
    console.error('Error from Backend API:', error.response ? error.response.data : error.message);
    return `Error from Backend API: ${error.message}`;
  }

  // Process and return the response
  // Adjust this part based on how you want to handle the response
  return response;
}


export async function ada_embeddings(input) {
  const inputArray = !Array.isArray(input) ? [input] : input;
  const cleanedInputs = inputArray.map(element => element.replace("[\n\r]+/gm", " | ").slice(0, 12000));

  try {
    const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/openai/adaEmbeddings`, { inputs: cleanedInputs }, { withCredentials: true });
    return response.data;
  } catch (error) {
    console.error('Error from Backend API:', error.response ? error.response.data : error.message);
    return `Error from Backend API: ${error.message}`;
  }
}

export function flatten(arr) {
  return arr.reduce((flat, toFlatten) => {
    return flat.concat(Array.isArray(toFlatten) ? flatten(toFlatten) : toFlatten);
  }, []);
}

export function unflatten(arr, pattern) {
  let index = 0;

  function unflattenHelper(pattern) {
    if (Array.isArray(pattern)) {
      return pattern.map(unflattenHelper);
    }
    return arr[index++];
  }
  return unflattenHelper(pattern);
}

export function deepMap(f, multiArray) {
  return multiArray.map(
    element => Array.isArray(element) ? deepMap(f, element) : f(element)
  );
}

export async function generateImageFromDALLE(prompt) {
  const endpoint = `${import.meta.env.VITE_REACT_APP_LEUMAS_AI_ENDPOINT}/openai/dalle/images/generate`;
  
  // Updated parameters to include 'n' and 'size'
  const parameters = {
    prompt: prompt,
    n: 1,     // As specified, always passing 1
    size: '512x512'  // Setting the size to 512x512
  };

  try {
    const response = await axios.post(endpoint, parameters);
    if (response.status === 200) {
      const imageUrl = response.data[0].url;  // Assuming response structure includes an URL
      console.log("imageURL", imageUrl);
      return imageUrl;
    } else {
      console.error('Error from Backend API:', response.data);
      return `Error from Backend API: ${response.statusText}`;
    }
  } catch (error) {
    console.error('Error in Backend request:', error);
    return 'An error occurred. Please try again.';
  }
}


export default gpt;
