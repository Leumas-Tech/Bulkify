import { useState , useEffect} from 'react';

import {gpt} from "./GptFunctions"
// (prompt = ['tell me that I forgot the prompt'], model = 'gpt-3.5-turbo') 
import { MdFolderOpen, MdPlayArrow, MdPause } from 'react-icons/md';
import { MdDelete, MdDownload } from 'react-icons/md';



import { fileTypes } from './fileTypes';

const Bulkify = () => {

  const [selectedGptPrompt, setSelectedGptPrompt] = useState('');
  const [customGptPrompt, setCustomGptPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const [queue, setQueue] = useState([]);
  const [model, setModel] = useState("gpt-3.5-turbo");
  const [currentProcessingBlock, setCurrentProcessingBlock] = useState(null);
  const [selectedFileIndex, setSelectedFileIndex] = useState(null);
  const [gptPrompt, setGptPrompt] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [blocksPerPage] = useState(5); // Adjust number of blocks per page as needed
  const [selectedFileType, setSelectedFileType] = useState(fileTypes[0]);
  const [blockDurations, setBlockDurations] = useState([]);
  const [processingStartTime, setProcessingStartTime] = useState(null);
  const [lastBlockDuration, setLastBlockDuration] = useState(null);
  const [currentBlockDuration, setCurrentBlockDuration] = useState(0);
  const [outputBlocks, setOutputBlocks] = useState([]);

  const predefinedPrompts = {
    prompt1: "Based on our json skelton, please provide an explanation for each of the following exp: keys, reccomend us a valid subTopic related to out subject and question please explain why each exp is either right or wrong, and return only our updated JSON. for each of our options A.B.C and D include a key value for exp:, please give an explanation for why the correct answer is correct, but also why the false answers are wrong. For our subtopics please include a related topic based on our question and topic \n Please ensure that you will only reply with the json, and reupdate all necessary keys. \n exp: provide an explanation for why that answer is right or wrong. \n subtopic: provide a related topic based on the topic and question",
    prompt2: "Skeleton for Prompt 2",
    // Add more predefined prompts here
  };

  const downloadFile = (block, fileType, fileName) => {
    const contentToDownload = block.response.data.choices[0].message.content;
    const blob = new Blob([JSON.stringify(contentToDownload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.${fileType}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  

  const handlePromptChange = (e) => {
    setSelectedGptPrompt(e.target.value);
    setCustomGptPrompt(''); // Clear custom prompt when selecting a predefined one
  };

  const handleCustomPromptChange = (e) => {
    setCustomGptPrompt(e.target.value);
    setGptPrompt(e.target.value);
    setSelectedGptPrompt('custom'); // Set to 'custom' when typing in the custom prompt textarea
  };

  // Determine which prompt to use (predefined or custom)
  const activeGptPrompt = selectedGptPrompt === 'custom' ? customGptPrompt : predefinedPrompts[selectedGptPrompt];

  const handleFolderChange = async () => {
    try {
      const directoryHandle = await window.showDirectoryPicker();
      let newQueue = [];

      for await (const entry of directoryHandle.values()) {
        if (entry.kind === 'file' && entry.name.endsWith('.json')) {
          const file = await entry.getFile();
          const content = await file.text();
          const jsonContent = JSON.parse(content);
          const blocks = Object.values(jsonContent).map(block => ({ ...block }));

          newQueue.push({ fileName: entry.name, blocks });
        }
      }

      setQueue(newQueue);
      setSelectedFileIndex(null);
    } catch (error) {
      console.error('Error processing folder:', error);
    }
  };

  // Select a file to view its blocks
  const handleFileSelect = (index) => {
    setSelectedFileIndex(index);
    setCurrentPage(1); // Reset to first page when a new file is selected
  };

  // Pagination Logic
  const currentFileBlocks = selectedFileIndex !== null ? queue[selectedFileIndex].blocks : [];
  const indexOfLastBlock = currentPage * blocksPerPage;
  const indexOfFirstBlock = indexOfLastBlock - blocksPerPage;
  const currentBlocks = currentFileBlocks.slice(indexOfFirstBlock, indexOfLastBlock);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);


  const calculateEstimatedCompletionTime = () => {
    if (blockDurations.length === 0) {
      return 'Calculating...';
    }
    const averageTime = blockDurations.reduce((acc, val) => acc + val, 0) / blockDurations.length;
    const remainingBlocks = totalBlocksInQueue() - blockDurations.length;
    return Math.round(averageTime * remainingBlocks); // Estimated time in seconds
  };

  useEffect(() => {
    let interval;
    if (processingStartTime) {
      interval = setInterval(() => {
        setCurrentBlockDuration(Math.floor((Date.now() - processingStartTime) / 1000));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [processingStartTime]);


  const toggleProcessing = () => {
    if (isProcessing) {
      // If processing is currently active, stop it
      setIsProcessing(false);
    } else {
      // If not processing, start it
      if (queue.length > 0) {
        setIsProcessing(true); // Set processing to true
        bulkifyProcessor(); // Start processing
      } else {
        console.log("No files in the queue to process.");
      }
    }
  };
  
  const bulkifyProcessor = async () => {
    console.log("Bulkify processor has begun");
  
    let updatedQueue = [...queue]; // Clone the queue
  
    for (let fileIndex in updatedQueue) {
      const fileName = updatedQueue[fileIndex].fileName.replace('.json', '');
      let allBlocksProcessed = true;
  
      for (let blockIndex in updatedQueue[fileIndex].blocks) {
  
        setCurrentProcessingBlock({ fileIndex, blockIndex });
        setProcessingStartTime(Date.now());
  
        let block = updatedQueue[fileIndex].blocks[blockIndex];
  
        try {
          const promptToSend = gptPrompt + JSON.stringify(block);
          console.log("Sending prompt ", promptToSend);
          await new Promise(resolve => setTimeout(resolve, 5000)); // Simulate delay
          const chatGptResponse = await gpt(promptToSend, model);
          console.log("Response: ", chatGptResponse);
  
          block.response = isValidJSON(chatGptResponse.data.choices[0].message.content, block) 
            ? chatGptResponse 
            : convertToValidJSON(chatGptResponse.data.choices[0].message.content, block);
  
          block.status = 'success';
          downloadFile(updatedQueue[fileIndex].blocks[blockIndex], selectedFileType, fileName, blockIndex);
          const responseContent = chatGptResponse.data.choices[0].message.content;
          block.response = responseContent;
          setOutputBlocks(prev => [...prev, {
            input: block,
            output: responseContent // Assuming this is already the content you need
          }]);
          
        } catch (error) {
          console.error('Error processing block:', error);
          block.status = 'error';
        }
  
        const duration = Math.floor((Date.now() - processingStartTime) / 1000);
        setBlockDurations(prev => [...prev, duration]);
        setLastBlockDuration(duration);
        setCurrentBlockDuration(0);
  
        if (updatedQueue[fileIndex].blocks[blockIndex].status !== 'success') {
          allBlocksProcessed = false;
        }
      }
  
      if (allBlocksProcessed) {
        const fileName = updatedQueue[fileIndex].fileName.replace('.json', '');
        downloadFile(updatedQueue[fileIndex].blocks, 'json', fileName);
      }
    }
  
    setIsProcessing(false); // Stop processing after completion
    setQueue(updatedQueue);
    setCurrentProcessingBlock(null); // Reset current processing block
  };
  

  const renderOutputBlocks = () => {
    return outputBlocks.map((item, index) => {
      let formattedOutput;
      try {
        // Parse the JSON string to an object and then stringify it back for proper formatting
        formattedOutput = JSON.stringify(JSON.parse(item.output), null, 2);
      } catch (error) {
        // In case of any parsing error, use the original output
        console.error("Error parsing JSON:", error);
        formattedOutput = item.output;
      }
  
      return (
        <div key={index} className={`border-2 rounded-lg p-2 shadow-xl text-sm overflow-y-auto bg-black text-white`}>
          <pre>{formattedOutput}</pre>
        </div>
      );
    });
  };
  
  
  

  // Function to combine and download all responses as a single JSON file
  const downloadCombinedJson = () => {
    const combinedData = outputBlocks.map(block => block.output);
    downloadFile(combinedData, 'json', 'combined_responses');
  };


  const downloadIndividualFile = (fileIndex) => {
    const file = queue[fileIndex];
    downloadFile(file.blocks, 'json', file.fileName.replace('.json', ''));
  };

    const getDurationColor = () => {
    if (lastBlockDuration === null) return 'text-black'; // No previous duration to compare
    return currentBlockDuration < lastBlockDuration ? 'text-green-500' : 'text-red-500';
  };

  // Utility function to check if a response is valid JSON
  const isValidJSON = (obj, original) => {
    try {
      JSON.parse(JSON.stringify(obj));
      return true;
    } catch (e) {
      return false;
    }
  };
  
  // Convert ChatGPT response to valid JSON format based on original block structure
// Convert ChatGPT response to valid JSON format based on original block structure
const convertToValidJSON = (response, originalBlock) => {
  // Implement logic to parse the response and structure it according to originalBlock
  // This is a placeholder, actual implementation will depend on the expected format
  // and the structure of the originalBlock
  let convertedResponse = { ...originalBlock };

  // Example: If originalBlock has specific keys, map response to those keys
  // This needs to be customized based on your specific JSON structure and needs
  for (let key in originalBlock) {
    if (Object.prototype.hasOwnProperty.call(response, key)) {
      convertedResponse[key] = response[key];
    } else {
      // If the key doesn't exist in the response, use the original block's value
      convertedResponse[key] = originalBlock[key];
    }
  }

  return convertedResponse;
};

  



  
const totalBlocksInQueue = () => {
  return queue.reduce((acc, file) => acc + file.blocks.length, 0);
};

// Function to calculate the number of blocks in the selected file
const blocksInSelectedFile = () => {
  if (selectedFileIndex !== null) {
    return queue[selectedFileIndex].blocks.length;
  }
  return 0;
};

const removeBlock = (fileIndex, blockIndex) => {
  const updatedQueue = [...queue];
  updatedQueue[fileIndex].blocks.splice(blockIndex, 1);
  setQueue(updatedQueue);
};

// Function to remove an entire file
const removeFile = (fileIndex) => {
  const updatedQueue = [...queue];
  updatedQueue.splice(fileIndex, 1);
  setQueue(updatedQueue);
  // Reset selected file index if the currently selected file is removed
  if (selectedFileIndex === fileIndex) {
    setSelectedFileIndex(null);
  }
};



  return (
    <div className={`flex items-center justify-between h-full w-full`}>


<aside className={`bg-gray-800 text-white p-4 flex flex-col  justify-between items-center border-2 rounded-lg max-w-[40vh] min-w-[200px] h-full overflow-y-scroll border-glow`}>

<button onClick={downloadCombinedJson} className="bg-green-500 hover:bg-green-600 text-white p-2 rounded-lg flex items-center justify-center">
        <MdDownload className="mr-2"/> Download Combined JSON
      </button>

<div className='flex justify-center items-center w-full w-full shadow-xl border-2 rounded-lg p-2'>

<select className={`textStyles w-full sm:w-auto bg-transparent shadow-xl  rounded-lg p-2 hoverEffect`} id="file-type" value={selectedFileType} onChange={(e) => setSelectedFileType(e.target.value)}>
  {fileTypes.map((fileType, index) => (
    <option className='text-black' key={index} value={fileType}>{fileType}</option>
  ))}
</select>

<div className="flex justify-center items-center w-full w-full shadow-xl  rounded-lg p-2">
  {/* <button onClick={bulkifyProcessor} className="mx-2">
    {isProcessing ? <MdPause /> : <MdPlayArrow />}
  </button> */}

  <button onClick={handleFolderChange} className="hoverEffect p-2 rounded-lg border-blue-400 border-2">
    <MdFolderOpen />
  </button>

  <button onClick={toggleProcessing}  className="hoverEffect p-2 rounded-lg border-blue-400 border-2">
    {isProcessing ? <MdPause /> : <MdPlayArrow />}
  </button>
</div>
  
</div>

  <div className='border-2 rounded-lg p-2'>
        <select className='bg-transparent w-full p-2 hoverEffect rounded-lg' value={selectedGptPrompt} onChange={handlePromptChange}>
          <option  className='bg-blue-400 text-white' value="">Select a predefined prompt</option>
          {Object.keys(predefinedPrompts).map(key => (
            <option  className='bg-blue-400 text-white' key={key} value={key}>{key}</option>
          ))}
          <option className='bg-blue-400 text-white' value="custom">Custom Prompt</option>
        </select>
        {selectedGptPrompt === 'custom' && (
          <textarea 
            value={customGptPrompt} 
            onChange={handleCustomPromptChange}
            placeholder="Enter custom GPT Prompt"
            className="bg-gray-700 p-2 rounded  w-full max-h-[200px] hoverEffect"
          />
        )}
      </div>

<div className="text-center sm:text-left w-full sm:w-auto border-2 rounded-lg p-2 text-[8px]">

  <div>Files: {queue.length}</div>
  <div>Total Blocks in Queue: {totalBlocksInQueue()}</div>
  <div>Blocks in Selected File: {blocksInSelectedFile()}</div>
  {currentProcessingBlock && (
    <div>
      <div>Processing Block: File {currentProcessingBlock.fileIndex}, Block {currentProcessingBlock.blockIndex}</div>
      <div>Estimated Time Until Complete: {calculateEstimatedCompletionTime()} seconds</div>
      <div className={`Elapsed Time Since Last Block: ${currentBlockDuration} seconds`} style={{ color: getDurationColor() }}></div>
    </div>
  )}
  <div className="flex items-center">
    {currentProcessingBlock && (
      <div className="text-center sm:text-left mr-4">
        <div>Processing Block: File {currentProcessingBlock.fileIndex}, Block {currentProcessingBlock.blockIndex}</div>
        <div>Estimated Time Until Complete: {calculateEstimatedCompletionTime()} seconds</div>
        <div className={`Elapsed Time Since Last Block: ${currentBlockDuration} seconds`} style={{ color: getDurationColor() }}></div>
      </div>
    )}
    <div className=" grid grid-cols-8">
      {Array.from({ length: Math.ceil(currentFileBlocks.length / blocksPerPage) }, (_, i) => (
        <button key={i} onClick={() => paginate(i + 1)} className="mx-1 text-xs p-1 bg-blue-500 hover:bg-blue-600 rounded">
          {i + 1}
        </button>
      ))}
    </div>


  </div>
</div>







<div className='grid grid-cols-1 overflow-y-scroll max-h-[200px] h-full w-full'>
  {queue.map((file, index) => (
    <div key={index} className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-center">
      <button className={`bg-blue-400 p-2 rounded-lg hoverEffect mb-2`} onClick={() => handleFileSelect(index)}>
        {file.fileName}
      </button>
      <div className="flex justify-around w-full">
        <button onClick={() => removeFile(index)} className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-lg flex items-center justify-center">
          <MdDelete className=""/> 
        </button>
        <button onClick={() => downloadIndividualFile(index)} className="bg-green-500 hover:bg-green-600 text-white p-2 rounded-lg flex items-center justify-center">
          <MdDownload className=""/> 
        </button>
      </div>
    </div>
  ))}
</div>      
</aside>




 <div className='grid grid-cols-1 md:grid-cols-2 gap-4 p-4 w-full rounded-lg shadow-lg h-full'>
        {/* Input Fieldset */}
        <fieldset className='border-2 rounded-lg p-4 grid grid-cols-1 overflow-y-scroll h-full z-40 bg-blue-400'>
          <legend className="font-bold text-lg mb-4">Input</legend>
          {currentBlocks.map((block, index) => (
            <div key={index} className={`border-2 rounded-lg p-2 shadow-xl text-sm overflow-y-auto ${currentProcessingBlock?.blockIndex === index ? 'bg-yellow-300' : ''}`}>
              <pre>{JSON.stringify(block, null, 2)}</pre>
            </div>
          ))}
        </fieldset>

        {/* Output Fieldset */}
        <fieldset className='border-2 rounded-lg p-4 grid grid-cols-1 overflow-y-scroll h-full z-50 bg-black text-white'>
          <legend className="font-bold text-lg mb-4">Output</legend>
          <div className='overflow-y-auto'>
            {renderOutputBlocks()}
          </div>
        </fieldset>
      </div>


    </div>
  );
};

export default Bulkify;



// Prompt
// based on our json skelton, please provide an explanation for each of the following exp: keys, reccomend us a valid subTopic related to out subject and question please explain why each exp is either right or wrong, and return only our updated JSON. for each of our options A.B.C and D include a key value for exp:, please give an explanation for why the correct answer is correct, but also why the false answers are wrong. For our subtopics please include a related topic based on our question and topic
// Please ensure that you will only reply with the json, and reupdate all necessary keys
//exp: provide an explanation for why that answer is right or wrong
//subtopic: provide a related topic based on the topic and question