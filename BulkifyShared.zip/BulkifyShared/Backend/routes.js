const express = require('express');
const router = express.Router();

const controller = require("./controllers")

// ====================================================================
//                           ChatGPT ChatCompletions Router(s)
// ====================================================================

router.post('/chat-completion', controller.ChatCompletion);

// ====================================================================

module.exports = router;
